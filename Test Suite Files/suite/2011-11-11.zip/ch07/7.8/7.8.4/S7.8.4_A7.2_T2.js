// Copyright 2009 the Sputnik authors.  All rights reserved.
// This code is governed by the BSD license found in the LICENSE file.

/**
 * UnicodeEscapeSequence :: u HexDigit (one, two or three time) is incorrect
 *
 * @path ch07/7.8/7.8.4/S7.8.4_A7.2_T2.js
 * @description :: HexDigit :: A
 * @negative
 */

//CHECK#1
"\uA"

